
package com.example;

public class ShoppingCart {

    public static void main(String[] args) {
        String cliente = "Mary Smith";
        String articulo = "Shirt";

	// variables numericas
        double precio = 21.99;
        int cantidad = 2;
        boolean sinStock=false;
        double impuesto = 1.04;
	double total;
	

	/*
         Si hay Stock y la cantidad vendida > 0,  
         Imprima el mensaje "El cliente -cliente ha comprado -cantidad -articulo por -total pesos "
         
         Si no hay Stock imprimir el respectivo mensaje. Si la cantidad <= 0 imprimir "Cantidad no valida"
        
        */
        
        
        
    }
    
}


