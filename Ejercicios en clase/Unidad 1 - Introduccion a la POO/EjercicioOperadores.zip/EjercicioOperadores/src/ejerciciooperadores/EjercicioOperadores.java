/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciooperadores;

/**
 *
 * @author JAIRO
 */
public class EjercicioOperadores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int x = (((25 - 5) * 4) / (2 - 10)) + 4;
        assert x==-6: "Valor x correcto";
        
        int a = 25 -5 * 4 / 2 -10 + 4;
        assert a==100: "Valor a correcto";        
        
        int b = ((20 * 4) / (2 - 10)) + 4;
        assert b==100: "Valor b correcto";
        
        int c = (80 / (2 - 10)) + 4;
        assert c==100: "Valor c correcto";
        
        int d = (80 / -8) + 4;
        assert d==100: "Valor d correcto";
        
        int e = -10 + 4;
        assert e==100: "Valor e correcto";
        
        int f = -6;
        assert f==-6: "Valor f correcto";
    }

}
