package com.example;






public class WhileLoopDemo {

    public static void main(String[] args) {
        int num = 1;
        while (num <= 200) {
            System.out.print(num + " ");
            num = num * 2;
        }
    }
}
