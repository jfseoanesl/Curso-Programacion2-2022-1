package com.example;
public class WhileLoopEx {

    public static void main(String[] args) {
        
        int acumulado = 10;
        
        /* 
        Utilizando la estructura while o do-while, calcule cuantos numeros positivos consecutivos 
        son necesarios para sobrepasar el acumulado. Se debe iniciar desde 1.
        */
        
        
        
    }
}
