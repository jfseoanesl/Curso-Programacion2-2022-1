package text01;

public class Text01 {
    public static void main(String[] args) {
      System.out.println("   /\\         /\\   ");
 System.out.println("  /  \\_______/  \\  ");
         System.out.println(" /               \\ ");
           System.out.println("(  /\\         /\\  )");
    System.out.println("====     V     ====");
                    System.out.println("======(__|__)======");
        System.out.println("  (             )  ");
 System.out.println("   (___________)   ");
}    
       }
