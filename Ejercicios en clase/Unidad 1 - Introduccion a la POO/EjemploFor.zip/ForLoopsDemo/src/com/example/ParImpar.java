
package com.example;

public class ParImpar {
    
    public static void main(String[] args) {
        
        int n = 50;
        
        System.out.println("Numeros pares hasta " + n + ": " );
        // imprimir los numeros pares hasta n
        
        
        
        System.out.println("Numeros impares hasta " + n + ": " );
        // imprimir los numeros impares hasta n
        
        
        

    }  
}
