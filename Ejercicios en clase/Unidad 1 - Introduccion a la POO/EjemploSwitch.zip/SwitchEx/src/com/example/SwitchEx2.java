/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */
public class SwitchEx2 {

    public static void main(String args[]) {
        
        int month = 10;
        
        /*
          Utilizando una estructura Switch imprima el nombre del mes correspondiente al valor de month
        */
        
    }
}
