
package chickens01;


/*
**PROBLEMA: 

− Las gallinas del granjero Paco Torres siempre ponen "eggsPerChicken" huevos cada día
− El lunes, Paco tiene "chickenCountpollos"
− El martes por la mañana, se hace con 1 gallina más
− El miércoles por la mañana, un zorro se come la mitad de las gallinas
− ¿Cuántos huevos consigue recoger Paco, si empieza con...?
    • eggsPerChicken = 5, chickenCount = 3
    • eggsPerChicken = 4, chickenCount = 8

*/

public class Chickens01 {
    public static void main(String[] args) {
        
        //int eggsPerChicken = 5, chickenCountPollos = 3;
        int eggsPerChicken = 4, chickenCountPollos = 8;
        
        // Dia Lunes
        int totalEggs = ?;
        
        //totalEggs Dia Martes
        
        
        // totalEggs dia miercoles
                
        
        
        System.out.println(totalEggs);
    }   
}
