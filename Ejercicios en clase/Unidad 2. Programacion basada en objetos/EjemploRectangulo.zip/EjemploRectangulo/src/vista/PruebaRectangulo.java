
package vista;

import modelo.Rectangulo;

/**
 *
 * @author JAIRO
 */
public class PruebaRectangulo {
    public static void main(String[] args) {
        
        Rectangulo r = new Rectangulo();
        r.setAltura(10);
        r.setBase(20);
        
        System.out.println("Base:                  " + r.getBase());
        System.out.println("Altura:                " + r.getAltura());
        System.out.println("Calculo del area:      " + r.calcularArea());
        System.out.println("Calculo del perimetro: " + r.calcularPerimetro());
        
        
    }
}
