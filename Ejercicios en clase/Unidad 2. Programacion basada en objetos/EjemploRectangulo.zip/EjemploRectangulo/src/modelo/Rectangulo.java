/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author JAIRO
 */
public class Rectangulo {
    
    // ATRIBUTOS DE INSTANCIA PARA LA BASE Y PARA LA ALTURA
    
    private double base;
    private double altura;
    
    
    // CONSTRUCTOR POR DEFECTO
    
    public Rectangulo(){
        this.base=0;
        this.altura=0;
    }
    
    
    // METODOS GETTER PARA LA BASAE Y PARA LA ALTURA

    /**
     * @return the base
     */
    public double getBase() {
        return base;
    }
    
     /**
     * @return the altura
     */
    public double getAltura() {
        return altura;
    }

    // METODOS SETTER PARA LA BASAE Y PARA LA ALTURA

    /**
     * @param base the base to set
     */
    public void setBase(double base) {
        this.base = base;
    }

   
    /**
     * @param altura the altura to set
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    // METODOS MIEMBROS PARA CALCULAR AREA Y CALCULAR PERIMETRO
    /**
     * 
     * @return area
     */
    public double calcularArea(){
        double area = this.base * this.altura;
        return area;
    }

    /**
     * 
     * @return perimetro
     */
    public double calcularPerimetro(){
        double perimetro = 2 * this.base + 2 * this.altura;
        return perimetro;
    }
    
    
}
